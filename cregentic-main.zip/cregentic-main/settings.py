"""All Settings must be declared here"""
model = 'ollama/mistral-nemo:latest'