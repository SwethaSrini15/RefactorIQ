MODEL_NAME= "ollama/hermes3:latest"
RESEARCH_LLM = 'ollama/mistral-nemo:latest'